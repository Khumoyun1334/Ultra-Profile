import React from 'react'
import Pro from '../../components/Pro'
import Krsavka from '../../components/Krsavka'

function SingleProducts() {
  return (
    <div className='mt-[-100px]'>
        <Pro/>
        <div className='mt-7'>

        </div>
        <Krsavka/>
    </div>
  )
}

export default SingleProducts