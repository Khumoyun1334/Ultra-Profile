import React from 'react'

import Ass from "../../images/men-01.jpg"
import ProductsC from '../../components/ProductsC'
import Pro from '../../components/Pro'

function Products() {
    return (
        <div className='mt-[-100px]'>
            <Pro />
            <ProductsC />

      
        </div>
    )
}

export default Products