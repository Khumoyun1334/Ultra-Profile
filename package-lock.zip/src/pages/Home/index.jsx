import React from 'react'
import Navbar from '../../components/Navbar'
import Cart from '../../components/Cart'
import Carusel from '../../components/Carusel'
import Exployer from '../../components/Exployer'
import SocialMedia from '../../components/SocialMediya'
import Buy from '../../components/Buy'

function Home() {
  return (
    <div>

        <Cart/>
        <Carusel/>

        <Exployer/>

        <SocialMedia/>
        <Buy/>

    </div>
  )
}

export default Home