import React from 'react'
import './App.css'
import './bootstrap.min.css'
import './flex-slider.css'
import './lightbox.css'
import './owl-carousel.css'

import { Route, Routes } from 'react-router'
import Home from './pages/Home'
import About from './pages/About'
import Footer from './components/Footer'
import Navbar from './components/Navbar'
import Products from './pages/Products'
import SingleProducts from './pages/SingleProducts'
import ContactUs from './pages/ContactUs'


const App = () => {
    return (
        <div>
            <Navbar/>
            <Routes>
                <Route path='/' element={<Home />} />
                <Route path='/about' element={<About />} />
                <Route path='/products' element={<Products />} />
                <Route path='/singleproducts' element={<SingleProducts />} />
                <Route path='/contactus' element={<ContactUs />} />
                


            </Routes>

            <Footer/>
        </div>
    )
}

export default App
